

GROUP H (TourdeFarnceProject)
x13489808 Eoin Diskon
x13112406 Navjot Singh Virk
x13114531 Soffyan Ali

At this stage you would be aware of Work breakdowns but for your ease - 
Eion did Gallery.
Navjot did Store.
Soffiyan did Routes.
Home is done by the whole group sitting together and planning the project(including Cathal).


x11103272 Cathal O Maoldomhnaigh(left the group later on due to personal problems).
Cathal was doing History.

Thanks 
Group H