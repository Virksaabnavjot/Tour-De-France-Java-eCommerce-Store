/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tourdefranceproject;

/**
 *
 * @author Administrator
 */
public class Description {
    //here d is for description
    String d1, d2,d3,d4,d5,d6,d7,d8,d9,d10;
    
    
    public Description(){
        d1 = "<html>Leeds was an important stronghold of the textile industry.<br>"
                + " After the wool that was woven there, the fabric of the <br> Yellow Jersey will mobilise the attention of the riders.<br>"
                + " Until now, the sports fanatics would mainly be stirred by <br> the white and blue colours of Leeds United, Premiere league <br>"
                + "champions back in 1992 thanks to the help of Monsieur Eric Cantona.<br> Well before that, the city was the birth place of one of the <br> "
                + "pioneers of women's cycling: back in the sixties, Beryl Burton <br>"
                + " indeed claimed seven World titles (track and road).</html>";
        
        d2="<html>Well before inspiring the final name of the most populated town <br>in the United-States, York developed from a Roman city. <br>Its antique name, Eburacum, actually links it to Evry, another stage city of<br> the 2014 Tour, where the riders will take off one last time, three weeks later. <br>Since that period, York has welcomed the professional cycling pack <br>on several occasions during the Milk Race or the Tour of Britain. <br>The last visit was back in 2009 for a stage conquered <br> by Australian Chris Sutton.</html>";
        d3="<html>Prince William and his wife Kate also have the title of<br> Duke and Duchess of Cambridge.<br> The city also shines thanks to the prestige of its university.<br> Its former students also reached excellence in terms of sports.<br> They were indeed the first, in 1856, to put down on paper <br>the rules of the game of football. </html>";
        d4="<html>Among the nicknames given to the coastal resort,<br> “Paradise of sports” underlines the diversity of activities set up at<br> Le Touquet. One of the oldest golf courses was designed<br> there back in 1904, while Suzanne Lenglen won the local tennis tournament<br> in 1913. Later, Thierry Sabine launched the Enduro bike race<br> in 1975</html>";
        d5="<html>Ypres, that will welcome the Tour de France for the very<br> first time, also hosts, like in most of the <br>towns of the country, a well established cycling meeting. The Kattekoers <br>(Cat race) which refers to the tradition of getting rid of cats that<br> were considered as a menace to the commercial prosperity of the city <br>specialised in the cloth industry, was created in 1934. </html>";
        d6="<html>An important trade fair city in the Middle Age, <br>Arras welcomed thousands of traders on its Grand'Place.<br> Nowadays the biggest pop and rock artists,<br> from Prince to Sting but also the Black Eyed Peas </html>";
        d7="<html>Ypres, that will welcome the Tour de France for the <br>very first time, also hosts, like in most of the towns of the country,<br> a well established cycling meeting. </html>";
        d8="<html>This neighbouring common of Nancy entered the club <br>of stage towns of the Tour de France in 2012.<br> It also hosts the Marcel Picot Stadium, home to the AS <br>Nancy-Lorraine football club. It was here that Michel<br> Platini made his professional debut. After a tremendous career, he organised his jubilee there in<br> the spring of 1988</html>";
        d9="<html>Arras welcomed thousands of traders on its Grand'Place.<br> Nowadays the biggest pop and rock artists,<br> from Prince to Sting but also the Black Eyed Peas</html>";
        d10="<html>In terms of cycling, Gerardmer is deeply linked to <br>the Tour de l'Avenir that has stopped there five times. <br>It was on that Vosges stage in 2009 that Romain Sicard had taken command of the race,<br> distancing the likes of Tejay Van Garderen, Rafael Vals Ferri and <br>Sergio Henao</html>";
        
        
        
        
        
        
        
        
    }
   
    public String getD1() {
        return d1;
    }

    public String getD2() {
        return d2;
    }

    public String getD3() {
        return d3;
    }

    public String getD4() {
        return d4;
    }

    public String getD5() {
        return d5;
    }

    public String getD6() {
        return d6;
    }

    public String getD7() {
        return d7;
    }

    public String getD8() {
        return d8;
    }

    public String getD9() {
        return d9;
    }

    public String getD10() {
        return d10;
    }
    
}
