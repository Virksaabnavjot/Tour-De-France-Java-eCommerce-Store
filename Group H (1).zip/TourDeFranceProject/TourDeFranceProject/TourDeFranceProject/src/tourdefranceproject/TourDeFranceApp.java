/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tourdefranceproject;

/**
 *
 * @author x13112406 Navjot Singh Virk
 */
public class TourDeFranceApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // TODO code application logic here
    TourDeFranceGUI groupH = new TourDeFranceGUI();
    groupH.setVisible(false);
    
    StoreGUI store = new StoreGUI();
    store.setVisible(true);
    
    
    
    
    }
}
/*This Project is from Group H.We made home GUI that is attached to All individual sections
Navjot Singh Virk  x13112406      I am doing StoreGUI i.e Store part
Eion Diskon  I am doing Gallery 
Soffyan Ali  I am doing Routes 
Cathal   I am doinng History

Thanks Frances 
Regards Group H*/