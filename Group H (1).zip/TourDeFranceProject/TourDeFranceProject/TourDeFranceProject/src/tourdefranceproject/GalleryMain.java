/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tourdefranceproject;

/**
 *
 * @author x13489808
 */
public class GalleryMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Gallery form= new Gallery();
                    form.setLocationRelativeTo(null);
                    form.setVisible(true);
    }
}
